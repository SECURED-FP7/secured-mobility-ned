#define MODE_BIGENDIAN 1
#include "cpio.c"
