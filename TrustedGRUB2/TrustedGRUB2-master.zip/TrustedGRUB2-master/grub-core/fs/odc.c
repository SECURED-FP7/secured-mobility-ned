#define MODE_ODC 1
#include "cpio.c"
