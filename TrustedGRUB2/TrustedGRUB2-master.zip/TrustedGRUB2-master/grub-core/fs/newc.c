#define MODE_NEWC 1
#include "cpio.c"
